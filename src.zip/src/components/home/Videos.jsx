import React from 'react'

const Videos = () => {
  return (
    <div className='h-full w-full'>
        <video autoPlay loop muted className='h-full w-full object-cover' src="https://download-video-ak.vimeocdn.com/v3-1/playback/36bc59b8-6671-4358-abc2-15555fc6ae59/69496b2d?__token__=st=1759319332~exp=1759322932~acl=%2Fv3-1%2Fplayback%2F36bc59b8-6671-4358-abc2-15555fc6ae59%2F69496b2d%2A~hmac=fc100c1ed5fc27252cefd0468d05577c394ecbbfc9caadfb36eb02c2c09f1900&r=dXMtZWFzdDE%3D"></video>
    </div>
  )
}

export default Videos