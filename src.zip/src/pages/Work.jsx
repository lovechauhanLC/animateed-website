import React from 'react'

const Work = () => {
  return (
    <div>
      Work
    </div>
  )
}

export default Work
