import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import React, { useRef } from "react";

const Agency = () => {

  const imgDivRef = useRef(null)

  useGSAP(function(){
    gsap.registerPlugin(ScrollTrigger)

    gsap.to(imgDivRef.current,{
      scrollTrigger:{
        trigger:imgDivRef.current,
        markers:true
      }
    })
  })

  return (
    <div className="bg-black">
      <div className="section1">
        <div ref={imgDivRef} className="h-[20vw] w-[15vw] overflow-hidden rounded-3xl absolute top-62 left-112">
          <img
            className="h-full w-full object-cover"
            src="https://k72.ca/images/teamMembers/Carl_480x640.jpg?w=480&h=640&fit=crop&s=f0a84706bc91a6f505e8ad35f520f0b7"
            alt=""
          />
        </div>

        <div className="relative font-[font2] ">
          <div className="mt-[56vh] ">
            <h1 className="text-[20vw] uppercase text-center leading-[17vw] ">
              SEVEN7Y TWO
            </h1>
          </div>
          <div className="pl-[40%] mt-20 ">
            <p className="text-6xl">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              &nbsp;We’re inquisitive and open-minded, and we make sure
              creativity crowds out ego from every corner. A brand is a living
              thing, with values, a personality and a story. If we ignore that,
              we can achieve short-term success, but not influence that goes the
              distance. We bring that perspective to every brand story we help
              tell.
            </p>
          </div>
        </div>
      </div>
      <div className="section2 h-screen">
      </div>
    </div>
  );
};

export default Agency;
